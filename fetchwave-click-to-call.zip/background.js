// Right-click a selected number: "Call with Fetchwave"
const e164 = (p) => { const t = (p || '').trim(); if (t.startsWith('+')) return '+' + t.replace(/\D/g, ''); const d = t.replace(/\D/g, ''); if (d.startsWith('27') && d.length === 11) return '+' + d; if (d.startsWith('0') && d.length === 10) return '+27' + d.slice(1); return d ? '+' + d : ''; };
async function openDial(number) {
  const { appUrl } = await chrome.storage.sync.get('appUrl');
  if (!appUrl) { chrome.runtime.openOptionsPage(); return; }
  chrome.tabs.create({ url: appUrl.replace(/#.*$/, '') + '#/dial/' + encodeURIComponent(e164(number)) });
}
chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({ id: 'fw-call', title: 'Call "%s" with Fetchwave', contexts: ['selection'] });
  const { appUrl } = await chrome.storage.sync.get('appUrl');
  if (!appUrl) chrome.runtime.openOptionsPage();
});
chrome.contextMenus.onClicked.addListener((info) => { if (info.menuItemId === 'fw-call' && info.selectionText) openDial(info.selectionText); });
chrome.runtime.onMessage.addListener((msg) => { if (msg && msg.type === 'fw-dial') openDial(msg.number); });
