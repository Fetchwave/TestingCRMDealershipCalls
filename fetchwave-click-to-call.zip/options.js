const u = document.getElementById('u'), ok = document.getElementById('ok');
chrome.storage.sync.get('appUrl').then(({ appUrl }) => { if (appUrl) u.value = appUrl; });
document.getElementById('s').addEventListener('click', async () => {
  const v = u.value.trim();
  if (!/^https:\/\//.test(v)) { ok.style.color = '#B3311A'; ok.textContent = 'Use the https:// address of the app'; return; }
  await chrome.storage.sync.set({ appUrl: v.replace(/#.*$/, '') }); ok.style.color = '#1A7A40'; ok.textContent = 'Saved';
});
