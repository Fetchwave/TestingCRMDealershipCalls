// Adds a small "Call" button after every South African phone number on the page.
(() => {
  const RE = /(?:\+27|\b0)[\s-]?\(?[1-8]\d\)?[\s-]?\d{3}[\s-]?\d{4}\b/g;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'CODE', 'PRE', 'SVG', 'BUTTON']);
  const style = document.createElement('style');
  style.textContent = '.fw-call{all:unset;display:inline-flex;align-items:center;gap:4px;margin-left:6px;padding:1px 8px;border-radius:999px;background:#1B78D2;color:#fff!important;font:600 11px/18px -apple-system,Segoe UI,Roboto,sans-serif;cursor:pointer;vertical-align:middle;white-space:nowrap}.fw-call:hover{background:#1668BA}.fw-call svg{width:11px;height:11px}';
  (document.head || document.documentElement).appendChild(style);
  const icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3h3l2 5-2.5 1.5a11 11 0 0 0 7 7L16 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/></svg>';
  const button = (num) => { const b = document.createElement('span'); b.className = 'fw-call'; b.setAttribute('role', 'button'); b.title = 'Call ' + num + ' with Fetchwave'; b.innerHTML = icon + 'Call'; b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); chrome.runtime.sendMessage({ type: 'fw-dial', number: num }); }, true); return b; };
  const okParent = (el) => { for (let p = el; p; p = p.parentElement) { if (SKIP.has(p.tagName) || p.isContentEditable || p.classList?.contains('fw-call') || p.classList?.contains('fw-num')) return false; } return true; };
  function scan(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: (n) => (RE.test(n.nodeValue) && (RE.lastIndex = 0, true) && okParent(n.parentElement)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT });
    const nodes = []; let n; while ((n = walker.nextNode())) nodes.push(n);
    for (const node of nodes.slice(0, 300)) {
      const text = node.nodeValue; RE.lastIndex = 0; let m, last = 0; const frag = document.createDocumentFragment(); let found = false;
      while ((m = RE.exec(text))) { found = true; frag.append(text.slice(last, m.index)); const sp = document.createElement('span'); sp.className = 'fw-num'; sp.textContent = m[0]; frag.append(sp, button(m[0])); last = m.index + m[0].length; }
      if (!found) continue; frag.append(text.slice(last)); node.replaceWith(frag);
    }
  }
  document.addEventListener('click', (e) => { const a = e.target.closest && e.target.closest('a[href^="tel:"]'); if (!a) return; e.preventDefault(); chrome.runtime.sendMessage({ type: 'fw-dial', number: decodeURIComponent(a.getAttribute('href').slice(4)) }); }, true);
  scan(document.body);
  let t = null; new MutationObserver(() => { clearTimeout(t); t = setTimeout(() => scan(document.body), 600); }).observe(document.body, { childList: true, subtree: true, characterData: true });
})();
